package com.example.ecommerce;

public class Payment {
    public void processPayment() {
        System.out.println("Payment processed.");
    }

    public void refundPayment() {
        System.out.println("Payment refunded.");
    }
}
