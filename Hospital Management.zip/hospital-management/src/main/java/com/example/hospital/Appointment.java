package com.example.hospital;

public class Appointment {
    public void bookAppointment() {
        System.out.println("Appointment booked.");
    }

    public void cancelAppointment() {
        System.out.println("Appointment cancelled.");
    }
}
